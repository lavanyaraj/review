package com.niit.ShoppingCart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.CategoryDAO;
import com.niit.ShoppingCart.model.Category;

public class CategoryTest {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		
		Category category = (Category) context.getBean("category");
	
	    CategoryDAO categoryDAO = (CategoryDAO)  context.getBean("categoryDAO");
	    
	    
	    category.setId("OG125");
        category.setName("OGNAME125");
        category.setDescription("OGDESC125");

       
        categoryDAO.saveorUpdate(category);
       
        categoryDAO.delete("OG125");



}


}