package com.niit.ShoppingCart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.CartDAO;
import com.niit.ShoppingCart.model.Cart;

public class CartTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		
		Cart ct =(Cart) context.getBean("cart");
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		
		
		ct.setId("Lavanya");
		ct.setPrice("10000");
		ct.setProductName("ROLEX");
		ct.setQuantity(1);
		ct.setStatus('N');
		cartDAO.saveorUpdate(ct);
}
}