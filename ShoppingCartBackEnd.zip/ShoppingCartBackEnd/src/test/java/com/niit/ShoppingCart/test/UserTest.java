package com.niit.ShoppingCart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.UserDAO;
import com.niit.ShoppingCart.model.User;




public class UserTest {
	
	static AnnotationConfigApplicationContext context;
	
	public UserTest()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
	}
	
	public static void createUser(User user)
	{
		
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		userDAO.saveorUpdate(user);
		
		
	}
	public static void main(String[] args) {
		UserTest t=new UserTest();
		User user = (User) context.getBean("user");
		user.setId("lavi");
		user.setPassword("1234");
		user.setIsAdmin("false");
		user.setAddress("chennai");
		user.setEmail("abdf@gmail.com");
		user.setMobile("9999999999");
		user.setName("lavanya");
		t.createUser(user);
		
		
		
	}

	

}
