package com.niit.ShoppingCart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.ProductDAO;
import com.niit.ShoppingCart.model.Product;

public class ProductTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	
	Product product = (Product) context.getBean("product");
	
    ProductDAO productDAO = (ProductDAO)  context.getBean("productDAO");

    product.setId("OG124");
    product.setName("OGNAME124");
    product.setDescription("OGDESC124");
    product.setPrice("1000");
    
    productDAO.saveorUpdate(product);
    
	
}
}
