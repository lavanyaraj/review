package com.niit.ShoppingCart.dao;

import java.util.List;

import com.niit.ShoppingCart.model.Cart;

public interface CartDAO {
	
	public List<Cart> list();
	public Cart get(String id);
	public void saveorUpdate(Cart Cart);
	public String delete(String id);
	public Long getTotalAmount(String id);
	

}
